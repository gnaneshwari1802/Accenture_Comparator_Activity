package com.accenture.lkm.activity;

import java.util.*;

public class StudentComparatorTester {

	public static void main(String[] args)
	{
		
				List<Student> s = new ArrayList<>();
				
				//Create students and add them to the ArrayList
				Student t1 = new Student("sai",105,"hyd",90);
				s.add(t1);

				Student t2 = new Student("keats",120,"chennai",100);
				s.add(t2);

				Student t3 = new Student("darsa",101,"pune",80);
				s.add(t3);

				//Printing all the details of students
				System.out.println("Students details are:");
				StudentService service = new StudentService();
				service.printAllStudentDetails(s);
				System.out.println();
				
				//Sorting all the details of student based on Student Id
				System.out.println("Sorting By Id:");
				Collections.sort(s,new SortByIdComparator());
				service.printAllStudentIdSorted(s);
				System.out.println();
				
				//Sorting all the details of student based on StudentName
				System.out.println("Sorting By Name:");
				Collections.sort(s,new SortByNameComparator());
				service.printAllStudentNameSorted(s);
				System.out.println();
				
				//Sorting all the details of student based on StudentMarks
				System.out.println("Sorting By Marks:");
				Collections.sort(s,new SortByMarksComparator());
				service.printAllStudentMarksSorted(s);
				System.out.println();			
	}

}
