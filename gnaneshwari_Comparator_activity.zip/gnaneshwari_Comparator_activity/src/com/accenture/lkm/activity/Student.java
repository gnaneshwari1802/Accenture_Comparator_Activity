package com.accenture.lkm.activity;

public class Student {
	private String Name;
	private int Id; 
	private String Address;
	private int Marks;
	public Student(String name,int id,String address,int marks) {
		this.Name=name;
		this.Id=id;
		this.Address=address;
		this.Marks=marks;
	}
	
	
	public String getName(){
		return Name;
		
	}
	public int getId() {
		return Id;
	}
	public String getAddress() {
		return Address;
	}
	public int getMarks() {
		return Marks;
	}
	

}
