package com.accenture.lkm.activity;

import java.util.List;

public class StudentService{

	
	public void printAllStudentIdSorted(List<Student> a){
		a.forEach(x->System.out.print("Student Id: "+x.getId()+" "));
	}
	
	public void printAllStudentNameSorted(List<Student> a) {
		a.forEach(x->System.out.print("Student Id: "+x.getName()+" "));
	}
	
	public void printAllStudentMarksSorted(List<Student> a) {
		a.forEach(x->System.out.println("Student Marks is "+x.getMarks()+" "));
	}
	public void printAllStudentDetails(List<Student> a)
	{
		a.forEach(x->System.out.println("Student Id: "+x.getId()+", "+
				"Student Name: "+x.getName()+", "+"Student Address: "+x.getAddress()+", "+"Student Marks: "
				+x.getMarks()));
	}
	
}
